#ifndef LOG_MAKER_H
#define LOG_MAKER_H

#define LOG_ERR         0    
#define LOG_WARNING     1    
#define LOG_NOTICE      2    
#define LOG_INFO        3    
#define LOG_DEBUG       4    


// TODO
void set_log_output_function(char* func);

void log_init(void);
void set_log_dir(char*);
void set_log_level(int level);
void close_log(void);

void log_msg_prefix(int level, char* filename, int linenum, const char* function);
void log_msg(int level, char *msg, ...);


char *log_filename;
int log_file_fd;

static int global_log_level = LOG_WARNING;

static int log_level_initialised = 0;

char* logging_dir;

#define LOG_THIS(level, msg, ...) do {                                \
        log_msg_prefix(level, __FILE__, __LINE__, __FUNCTION__);      \
        log_msg(level, msg, __VA_ARGS__);                             \
    } while (0)


#endif /* LOG_MAKER_H_H */
