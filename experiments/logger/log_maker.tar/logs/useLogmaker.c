#include "log_maker.h"
#include <stdio.h>
#include <unistd.h>

void function_one(void)
{
    LOG_THIS(LOG_WARNING,"variable one = %d, %d, %d,%d, %d, %d, %d, %d, %d, %d "
                  "%d, %d, %d,%d, %d, %d, %d, %d, %d, %d\n", 
                  1,2,3,4,5,6,7,8,9,10,
                  1,2,3,4,5,6,7,8,9,10);
}

void function_two(void)
{
    LOG_THIS(LOG_NOTICE,"variable two = %d, %d, %d,%d, %d, %d, %d, %d, %d, %d "
                  "%d, %d, %d,%d, %d, %d, %d, %d, %d, %d\n", 
                  1,2,3,4,5,6,7,8,9,10,
                  1,2,3,4,5,6,7,8,9,10);
}

int main(int argc, char *argv[])
{
    set_log_level(LOG_DEBUG);
    set_log_dir("/tmp/foo/bar/");
    log_init();

    function_one();
    function_two();

    close_log();
    return 0;
}
